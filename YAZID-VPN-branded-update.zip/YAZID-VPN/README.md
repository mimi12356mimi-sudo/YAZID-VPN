# YAZID VPN — Android starter

Brand: YAZID VPN  
Application ID: `com.yazid.vpn`  
Theme: dark purple  
Logo direction: text wordmark  
Language: Kotlin + Jetpack Compose

## What's included
- Android Studio / Gradle project scaffold
- Persian dark-purple home screen concept
- Branded connect/disconnect screen prototype (not yet a real VPN connection)
- Server selector UI placeholder
- Usage/subscription summary placeholders
- Initial project architecture folders for Xray, WireGuard, Sanaei and Mirza integration

## Important status
This is **not yet a working VPN APK**. The connect button is currently a UI prototype only. No Xray/WireGuard engine, subscription parser, backend credentials, Sanaei API calls, or Mirza integration have been added yet.

## APK filename
The debug build is named `YAZID-VPN.apk`.

## Build
Open this folder in Android Studio (recent stable version), allow Gradle sync, then run the `app` configuration on an Android device or emulator. JDK 17 is recommended.

## Next implementation stages
1. Confirm the exact Sanaei API endpoint/auth method and the subscription URL format.
2. Decide how users authenticate with Mirza (Telegram user ID/deep link or subscription token). Do not embed panel admin credentials in the APK.
3. Add a small backend that securely talks to Sanaei and Mirza; the app should receive short-lived user-scoped data only.
4. Integrate a maintained Android Xray/VPN service implementation and Android `VpnService` consent flow.
5. Add WireGuard through its supported Android integration separately from Xray profiles.
6. Add real traffic/expiry data, server health and release signing.

Never commit API keys, panel passwords, private keys, or production subscription URLs to source control.
