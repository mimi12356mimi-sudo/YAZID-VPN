package com.yazid.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.yazid.vpn.ui.screens.HomeScreen
import com.yazid.vpn.ui.theme.YazidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YazidTheme { HomeScreen() } }
    }
}
