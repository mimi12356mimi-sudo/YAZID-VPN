package com.yazid.vpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen() {
    var connected by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Germany · DE") }
    val purple = Color(0xFFB78CFF)

    Scaffold(containerColor = Color(0xFF0B0911), bottomBar = {
        NavigationBar(containerColor = Color(0xFF171321), contentColor = purple) {
            NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
            NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Dns, null) }, label = { Text("سرورها") })
            NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حساب") })
            NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("تنظیمات") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 22.dp)) {
            Spacer(Modifier.height(28.dp))
            Text("YAZID VPN", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text("SECURE  •  FAST  •  PRIVATE", color = purple, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(30.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171321)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = purple)
                        Spacer(Modifier.width(8.dp))
                        Text("وضعیت اتصال", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text(if (connected) "متصل" else "قطع", color = if (connected) Color(0xFF66D6A5) else Color.LightGray)
                    }
                    Spacer(Modifier.height(24.dp))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(190.dp).background(Brush.radialGradient(listOf(Color(0xFF55318A), Color(0xFF21172F), Color(0xFF171321))), CircleShape), contentAlignment = Alignment.Center) {
                            Button(onClick = { connected = !connected }, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = purple, contentColor = Color(0xFF24123D)), modifier = Modifier.size(126.dp)) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PowerSettingsNew, null, modifier = Modifier.size(36.dp))
                                    Text(if (connected) "قطع اتصال" else "اتصال", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(if (connected) "در نسخه بعدی اتصال واقعی فعال می‌شود" else "برای شروع، سرور موردنظر را انتخاب کن", color = Color(0xFFB9B0C7), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("سرور انتخاب‌شده", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Card(onClick = { selected = if (selected.startsWith("Germany")) "Turkey · TR" else "Germany · DE" }, colors = CardDefaults.cardColors(containerColor = Color(0xFF171321)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Public, null, tint = purple, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(selected, color = Color.White, fontWeight = FontWeight.SemiBold); Text("برای تغییر لمس کن", color = Color(0xFFAAA1B8), fontSize = 11.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoTile("حجم مصرفی", "—", Modifier.weight(1f))
                InfoTile("اعتبار اشتراک", "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            Text("این نسخه پیش‌نمایش رابط کاربری است؛ اتصال شبکه و دریافت اشتراک در مراحل بعدی پیاده‌سازی می‌شوند.", color = Color(0xFF8E849C), fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun InfoTile(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF171321)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Text(title, color = Color(0xFFAAA1B8), fontSize = 11.sp); Spacer(Modifier.height(6.dp)); Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
    }
}
