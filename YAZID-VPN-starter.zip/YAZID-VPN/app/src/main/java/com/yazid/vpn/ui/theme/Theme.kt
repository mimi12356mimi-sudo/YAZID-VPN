package com.yazid.vpn.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val YazidColors = darkColorScheme(
    primary = Color(0xFFB78CFF),
    onPrimary = Color(0xFF24123D),
    secondary = Color(0xFF8B5CF6),
    background = Color(0xFF0B0911),
    surface = Color(0xFF171321),
    surfaceVariant = Color(0xFF241D31),
    onBackground = Color(0xFFF7F1FF),
    onSurface = Color(0xFFF7F1FF)
)

@Composable
fun YazidTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = YazidColors, content = content)
}
